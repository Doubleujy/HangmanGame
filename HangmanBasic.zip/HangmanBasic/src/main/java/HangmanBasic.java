/**
 * Group Number: 1
 * Names: Shawn, Jing Yuan, Kyros
 *
 * PURPOSE: This is the pilot and controller of the game.It coordinates all other components and manages the game flow.
 */

public class HangmanBasic {

    //step 1.1: main method
    public static void main(String[] args) {
        try {
            // ============================================
            // INITIALIZATION PHASE
            // ============================================

            //step 1.2: create WordLoader object
            WordLoader wordLoader = new WordLoader();

            //step 1.3: create GameUI object
            GameUI ui = new GameUI();

            //step 1.4: display welcome message
            ui.displayWelcomeMessage();

            // ============================================
            // GAME SETUP PHASE
            // ============================================
            // Step 1.5: Get random word from WordLoader
            String targetWord = wordLoader.getRandomWord();

            // Step 1.6: Inform player about word length
            System.out.println("A word has been chosen. It has "
                    + targetWord.length() + " letters.");

            // Step 1.7: Create GameLogic object with the chosen word
            GameLogic game = new GameLogic(targetWord);

            // ============================================
            // MAIN GAME LOOP
            // ============================================
            // Step 1.8: Loop continues until game is over
            while (!game.isGameOver()) {
                // Step 1.8.1: Display current game state
                ui.displayGameState(game);

                // Step 1.8.2: Get player's guess
                char guess = ui.getPlayerGuess();

                // Step 1.8.3: Process the guess
                boolean validGuess = game.makeGuess(guess);

                // Step 1.8.4: Handle invalid/duplicate guess
                if (!validGuess) {
                    ui.displayInvalidGuessMessage();
                }

                // Loop repeats, showing updated state after each guess
            }

            // ============================================
            // GAME END PHASE
            // ============================================
            // Step 1.9: Display final result
            ui.displayGameResult(game);

            // Step 1.10: Clean up resources
            ui.close();

        } catch (Exception a) {
            // Step 1.11: Global error handling
            // Catches ANY unexpected error during execution

            System.err.println("Invalid input:" + a.getMessage());
            System.err.println("Please restart the game.");
        }
    }
}
